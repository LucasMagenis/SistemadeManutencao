package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.HistoricoPreventivoDTO;
import com.bd2.sistemamanutencao.entity.HistoricoPreventivo;
import org.springframework.stereotype.Component;

@Component
public class HistoricoPreventivoMapper {

    public HistoricoPreventivoDTO toDTO(HistoricoPreventivo entity) {
        return HistoricoPreventivoDTO.builder()
                .id(entity.getId())
                .idEquipamento(entity.getIdEquipamento())
                .tipoManutencao(entity.getTipoManutencao())
                .dataUltimoServico(entity.getDataUltimoServico())
                .dataProximoServico(entity.getDataProximoServico())
                .build();
    }

    public HistoricoPreventivo toEntity(HistoricoPreventivoDTO dto) {
        return HistoricoPreventivo.builder()
                .id(dto.getId())
                .idEquipamento(dto.getIdEquipamento())
                .tipoManutencao(dto.getTipoManutencao())
                .dataUltimoServico(dto.getDataUltimoServico())
                .dataProximoServico(dto.getDataProximoServico())
                .build();
    }
}
