package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.FornecedorDTO;
import com.bd2.sistemamanutencao.entity.Fornecedor;
import org.springframework.stereotype.Component;

@Component
public class FornecedorMapper {

    public FornecedorDTO toDTO(Fornecedor entity) {
        return FornecedorDTO.builder()
                .id(entity.getId())
                .nome(entity.getNome())
                .cnpj(entity.getCnpj())
                .contato(entity.getContato())
                .build();
    }

    public Fornecedor toEntity(FornecedorDTO dto) {
        return Fornecedor.builder()
                .id(dto.getId())
                .nome(dto.getNome())
                .cnpj(dto.getCnpj())
                .contato(dto.getContato())
                .build();
    }
}
