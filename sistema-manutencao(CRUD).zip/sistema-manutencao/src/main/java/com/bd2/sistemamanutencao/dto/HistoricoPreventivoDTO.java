package com.bd2.sistemamanutencao.dto;

import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HistoricoPreventivoDTO {

    private UUID id;
    private UUID idEquipamento;
    private String tipoManutencao;
    private LocalDate dataUltimoServico;
    private LocalDate dataProximoServico;
}
