package com.bd2.sistemamanutencao.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "falha")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Falha {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private UUID id;

    @Column(name = "equipamento_id", nullable = false)
    private UUID equipamentoId;

    @Column(name = "descricao_falha", nullable = false)
    private String descricaoFalha;

    @Column(name = "data_falha")
    private LocalDate dataFalha;

    @Column(name = "status", nullable = false)
    private String status;
}
