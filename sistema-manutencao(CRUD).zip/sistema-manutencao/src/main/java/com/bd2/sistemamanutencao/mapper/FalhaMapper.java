package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.FalhaDTO;
import com.bd2.sistemamanutencao.entity.Falha;
import org.springframework.stereotype.Component;

@Component
public class FalhaMapper {

    public FalhaDTO toDTO(Falha falha) {
        return FalhaDTO.builder()
                .id(falha.getId())
                .equipamentoId(falha.getEquipamentoId())
                .descricaoFalha(falha.getDescricaoFalha())
                .dataFalha(falha.getDataFalha())
                .status(falha.getStatus())
                .build();
    }

    public Falha toEntity(FalhaDTO dto) {
        return Falha.builder()
                .id(dto.getId())
                .equipamentoId(dto.getEquipamentoId())
                .descricaoFalha(dto.getDescricaoFalha())
                .dataFalha(dto.getDataFalha())
                .status(dto.getStatus())
                .build();
    }
}
