package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.ManutencaoDTO;
import com.bd2.sistemamanutencao.entity.Manutencao;
import org.springframework.stereotype.Component;

@Component
public class ManutencaoMapper {

    public ManutencaoDTO toDTO(Manutencao m) {
        return ManutencaoDTO.builder()
                .id(m.getId())
                .tipo(m.getTipo())
                .descricao(m.getDescricao())
                .status(m.getStatus())
                .equipamentoId(m.getEquipamentoId())
                .tecnicoId(m.getTecnicoId())
                .build();
    }

    public Manutencao toEntity(ManutencaoDTO dto) {
        return Manutencao.builder()
                .id(dto.getId())
                .tipo(dto.getTipo())
                .descricao(dto.getDescricao())
                .status(dto.getStatus())
                .equipamentoId(dto.getEquipamentoId())
                .tecnicoId(dto.getTecnicoId())
                .build();
    }
}