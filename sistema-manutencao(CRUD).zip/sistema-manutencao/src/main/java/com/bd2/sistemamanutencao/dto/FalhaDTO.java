package com.bd2.sistemamanutencao.dto;

import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FalhaDTO {
    private UUID id;
    private UUID equipamentoId;
    private String descricaoFalha;
    private LocalDate dataFalha;
    private String status;
}
