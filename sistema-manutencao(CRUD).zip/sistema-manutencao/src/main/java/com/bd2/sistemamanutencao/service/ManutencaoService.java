package com.bd2.sistemamanutencao.service;

import com.bd2.sistemamanutencao.dto.ManutencaoDTO;
import com.bd2.sistemamanutencao.entity.Manutencao;
import com.bd2.sistemamanutencao.mapper.ManutencaoMapper;
import com.bd2.sistemamanutencao.repository.ManutencaoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ManutencaoService {

    private final ManutencaoRepository repository;
    private final ManutencaoMapper mapper;

    public ManutencaoService(ManutencaoRepository repository, ManutencaoMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public List<ManutencaoDTO> listarTodos() {
        return repository.findAll().stream().map(mapper::toDTO).collect(Collectors.toList());
    }

    public ManutencaoDTO buscarPorId(UUID id) {
        return repository.findById(id).map(mapper::toDTO).orElse(null);
    }

    public ManutencaoDTO salvar(ManutencaoDTO dto) {
        Manutencao entity = mapper.toEntity(dto);
        return mapper.toDTO(repository.save(entity));
    }

    public void deletar(UUID id) {
        repository.deleteById(id);
    }

    public ManutencaoDTO atualizar(UUID id, ManutencaoDTO dto) {
        if (!repository.existsById(id)) return null;
        dto.setId(id);
        return salvar(dto);
    }
}