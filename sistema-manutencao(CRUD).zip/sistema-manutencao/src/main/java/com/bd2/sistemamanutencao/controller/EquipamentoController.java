package com.bd2.sistemamanutencao.controller;

import com.bd2.sistemamanutencao.dto.EquipamentoDTO;
import com.bd2.sistemamanutencao.service.EquipamentoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/equipamentos")
public class EquipamentoController {

    private final EquipamentoService service;

    public EquipamentoController(EquipamentoService service) {
        this.service = service;
    }

    @GetMapping
    public List<EquipamentoDTO> listarTodos() {
        return service.listarTodos();
    }

    @GetMapping("/{id}")
    public EquipamentoDTO buscarPorId(@PathVariable UUID id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public EquipamentoDTO salvar(@RequestBody EquipamentoDTO dto) {
        return service.salvar(dto);
    }

    @PutMapping("/{id}")
    public EquipamentoDTO atualizar(@PathVariable UUID id, @RequestBody EquipamentoDTO dto) {
        return service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable UUID id) {
        service.deletar(id);
    }
}
