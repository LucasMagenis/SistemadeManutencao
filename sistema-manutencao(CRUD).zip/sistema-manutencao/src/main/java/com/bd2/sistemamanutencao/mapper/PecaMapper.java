package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.PecaDTO;
import com.bd2.sistemamanutencao.entity.Peca;
import org.springframework.stereotype.Component;

@Component
public class PecaMapper {

    public PecaDTO toDTO(Peca peca) {
        return PecaDTO.builder()
                .id(peca.getId())
                .nome(peca.getNome())
                .descricao(peca.getDescricao())
                .quantidadeEstoque(peca.getQuantidadeEstoque())
                .custoUnitario(peca.getCustoUnitario())
                .build();
    }

    public Peca toEntity(PecaDTO dto) {
        return Peca.builder()
                .id(dto.getId())
                .nome(dto.getNome())
                .descricao(dto.getDescricao())
                .quantidadeEstoque(dto.getQuantidadeEstoque())
                .custoUnitario(dto.getCustoUnitario())
                .build();
    }
}
