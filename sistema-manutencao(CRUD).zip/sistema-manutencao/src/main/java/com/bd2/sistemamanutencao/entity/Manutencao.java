package com.bd2.sistemamanutencao.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import java.util.UUID;

@Entity
@Table(name = "manutencao")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Manutencao {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private UUID id;

    @Column(name = "tipo_manutencao")
    private String tipo;

    private String descricao;

    @Column(name = "status_manutencao")
    private String status;

    @Column(name = "equipamento_id")
    private UUID equipamentoId;

    @Column(name = "tecnico_id")
    private UUID tecnicoId;
}