package com.bd2.sistemamanutencao.repository;

import com.bd2.sistemamanutencao.entity.HistoricoPreventivo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface HistoricoPreventivoRepository extends JpaRepository<HistoricoPreventivo, UUID> {
}
