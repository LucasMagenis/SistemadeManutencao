package com.bd2.sistemamanutencao.service;

import com.bd2.sistemamanutencao.dto.FornecedorDTO;
import com.bd2.sistemamanutencao.entity.Fornecedor;
import com.bd2.sistemamanutencao.mapper.FornecedorMapper;
import com.bd2.sistemamanutencao.repository.FornecedorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service

public class FornecedorService {

    private final FornecedorRepository repository;
    private final FornecedorMapper mapper;

    public FornecedorService(FornecedorRepository repository, FornecedorMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public List<FornecedorDTO> listarTodos() {
        return repository.findAll().stream().map(mapper::toDTO).collect(Collectors.toList());
    }

    public FornecedorDTO buscarPorId(UUID id) {
        return repository.findById(id).map(mapper::toDTO).orElse(null);
    }

    public FornecedorDTO salvar(FornecedorDTO dto) {
        Fornecedor entity = mapper.toEntity(dto);
        return mapper.toDTO(repository.save(entity));
    }

    public void deletar(UUID id) {
        repository.deleteById(id);
    }

    public FornecedorDTO atualizar(UUID id, FornecedorDTO dto) {
        if (!repository.existsById(id)) return null;
        dto.setId(id);
        return salvar(dto);
    }
}
