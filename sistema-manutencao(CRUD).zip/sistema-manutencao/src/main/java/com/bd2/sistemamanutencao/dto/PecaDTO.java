package com.bd2.sistemamanutencao.dto;

import lombok.*;

import java.math.BigDecimal;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PecaDTO {
    private UUID id;
    private String nome;
    private String descricao;
    private int quantidadeEstoque;
    private BigDecimal custoUnitario;
}
