package com.bd2.sistemamanutencao.dto;

import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OrcamentoDTO {

    private UUID id;
    private UUID manutencaoId;  // Para relacionamento externo via DTO
    private String descricao;
    private Double valorTotal;
    private LocalDate dataOrcamento;

}
