package com.bd2.sistemamanutencao.service;

import com.bd2.sistemamanutencao.dto.EquipamentoDTO;
import com.bd2.sistemamanutencao.entity.Equipamento;
import com.bd2.sistemamanutencao.mapper.EquipamentoMapper;
import com.bd2.sistemamanutencao.repository.EquipamentoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class EquipamentoService {

    private final EquipamentoRepository repository;

    public EquipamentoService(EquipamentoRepository repository) {
        this.repository = repository;
    }

    public List<EquipamentoDTO> listarTodos() {
        return repository.findAll().stream()
                .map(EquipamentoMapper::toDTO)
                .collect(Collectors.toList());
    }

    public EquipamentoDTO buscarPorId(UUID id) {
        return repository.findById(id)
                .map(EquipamentoMapper::toDTO)
                .orElseThrow(() -> new RuntimeException("Equipamento não encontrado"));
    }

    public EquipamentoDTO salvar(EquipamentoDTO dto) {
        Equipamento equipamento = EquipamentoMapper.toEntity(dto);
        return EquipamentoMapper.toDTO(repository.save(equipamento));
    }

    public EquipamentoDTO atualizar(UUID id, EquipamentoDTO dto) {
        Equipamento existente = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Equipamento não encontrado"));

        existente.setNome(dto.getNome());
        existente.setModelo(dto.getModelo());
        existente.setFabricante(dto.getFabricante());

        return EquipamentoMapper.toDTO(repository.save(existente));
    }

    public void deletar(UUID id) {
        repository.deleteById(id);
    }
}
