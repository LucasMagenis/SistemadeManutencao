package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.OrcamentoDTO;
import com.bd2.sistemamanutencao.entity.Manutencao;
import com.bd2.sistemamanutencao.entity.Orcamento;
import com.bd2.sistemamanutencao.repository.ManutencaoRepository;
import org.springframework.stereotype.Component;

@Component
public class OrcamentoMapper {

    private final ManutencaoRepository manutencaoRepository;

    public OrcamentoMapper(ManutencaoRepository manutencaoRepository) {
        this.manutencaoRepository = manutencaoRepository;
    }

    public OrcamentoDTO toDTO(Orcamento entity) {
        OrcamentoDTO dto = new OrcamentoDTO();
        dto.setId(entity.getId());
        dto.setDescricao(entity.getDescricao());
        dto.setValorTotal(entity.getValorTotal());
        dto.setDataOrcamento(entity.getDataOrcamento());

        if (entity.getManutencao() != null) {
            dto.setManutencaoId(entity.getManutencao().getId());
        }

        return dto;
    }

    public Orcamento toEntity(OrcamentoDTO dto) {
        Orcamento entity = new Orcamento();
        entity.setId(dto.getId());
        entity.setDescricao(dto.getDescricao());
        entity.setValorTotal(dto.getValorTotal());
        entity.setDataOrcamento(dto.getDataOrcamento());

        if (dto.getManutencaoId() != null) {
            Manutencao manutencao = manutencaoRepository.findById(dto.getManutencaoId()).orElse(null);
            entity.setManutencao(manutencao);
        } else {
            entity.setManutencao(null);
        }

        return entity;
    }
}
