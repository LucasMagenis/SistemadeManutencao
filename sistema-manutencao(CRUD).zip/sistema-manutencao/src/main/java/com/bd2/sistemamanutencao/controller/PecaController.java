package com.bd2.sistemamanutencao.controller;

import com.bd2.sistemamanutencao.dto.PecaDTO;
import com.bd2.sistemamanutencao.service.PecaService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/pecas")
public class PecaController {

    private final PecaService service;

    public PecaController(PecaService service) {
        this.service = service;
    }

    @GetMapping
    public List<PecaDTO> listarTodos() {
        return service.listarTodos();
    }

    @GetMapping("/{id}")
    public PecaDTO buscarPorId(@PathVariable UUID id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public PecaDTO salvar(@RequestBody PecaDTO dto) {
        return service.salvar(dto);
    }

    @PutMapping("/{id}")
    public PecaDTO atualizar(@PathVariable UUID id, @RequestBody PecaDTO dto) {
        return service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable UUID id) {
        service.deletar(id);
    }
}
