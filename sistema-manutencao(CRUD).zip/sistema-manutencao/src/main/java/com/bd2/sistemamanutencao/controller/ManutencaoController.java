package com.bd2.sistemamanutencao.controller;

import com.bd2.sistemamanutencao.dto.ManutencaoDTO;
import com.bd2.sistemamanutencao.service.ManutencaoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/manutencoes")
public class ManutencaoController {

    private final ManutencaoService service;

    public ManutencaoController(ManutencaoService service) {
        this.service = service;
    }

    @GetMapping
    public List<ManutencaoDTO> listarTodos() {
        return service.listarTodos();
    }

    @GetMapping("/{id}")
    public ManutencaoDTO buscarPorId(@PathVariable UUID id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public ManutencaoDTO salvar(@RequestBody ManutencaoDTO dto) {
        return service.salvar(dto);
    }

    @PutMapping("/{id}")
    public ManutencaoDTO atualizar(@PathVariable UUID id, @RequestBody ManutencaoDTO dto) {
        return service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable UUID id) {
        service.deletar(id);
    }
}