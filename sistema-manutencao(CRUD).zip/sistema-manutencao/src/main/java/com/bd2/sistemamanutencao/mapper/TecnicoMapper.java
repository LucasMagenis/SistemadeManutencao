package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.TecnicoDTO;
import com.bd2.sistemamanutencao.entity.Tecnico;

public class TecnicoMapper {

    public static TecnicoDTO toDTO(Tecnico tecnico) {
        TecnicoDTO dto = new TecnicoDTO();
        dto.setId(tecnico.getId());
        dto.setNome(tecnico.getNome());
        dto.setEspecialidade(tecnico.getEspecialidade());
        dto.setContato(tecnico.getContato());
        return dto;
    }

    public static Tecnico toEntity(TecnicoDTO dto) {
        Tecnico tecnico = new Tecnico();
        tecnico.setId(dto.getId());
        tecnico.setNome(dto.getNome());
        tecnico.setEspecialidade(dto.getEspecialidade());
        tecnico.setContato(dto.getContato());
        return tecnico;
    }
}
