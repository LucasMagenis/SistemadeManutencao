package com.bd2.sistemamanutencao.dto;

import lombok.*;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ManutencaoDTO {
    private UUID id;
    private String tipo;
    private String descricao;
    private String status;
    private UUID equipamentoId;
    private UUID tecnicoId;
}