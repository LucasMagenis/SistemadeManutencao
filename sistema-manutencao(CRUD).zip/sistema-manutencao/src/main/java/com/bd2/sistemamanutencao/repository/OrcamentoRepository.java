package com.bd2.sistemamanutencao.repository;

import com.bd2.sistemamanutencao.entity.Orcamento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface OrcamentoRepository extends JpaRepository<Orcamento, UUID> {
}
