package com.bd2.sistemamanutencao.entity;

import jakarta.persistence.*;
import lombok.*;
import java.util.UUID;

@Entity
@Table(name = "equipamento")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Equipamento {

    @Id
    @GeneratedValue
    private UUID id;

    private String nome;
    private String modelo;
    private String fabricante;
}
