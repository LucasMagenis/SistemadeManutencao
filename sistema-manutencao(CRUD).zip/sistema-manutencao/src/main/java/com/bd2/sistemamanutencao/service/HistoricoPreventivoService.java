package com.bd2.sistemamanutencao.service;

import com.bd2.sistemamanutencao.dto.HistoricoPreventivoDTO;
import com.bd2.sistemamanutencao.entity.HistoricoPreventivo;
import com.bd2.sistemamanutencao.mapper.HistoricoPreventivoMapper;
import com.bd2.sistemamanutencao.repository.HistoricoPreventivoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class HistoricoPreventivoService {

    private final HistoricoPreventivoRepository repository;
    private final HistoricoPreventivoMapper mapper;

    public HistoricoPreventivoService(HistoricoPreventivoRepository repository, HistoricoPreventivoMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public List<HistoricoPreventivoDTO> listarTodos() {
        return repository.findAll().stream().map(mapper::toDTO).collect(Collectors.toList());
    }

    public HistoricoPreventivoDTO buscarPorId(UUID id) {
        return repository.findById(id).map(mapper::toDTO).orElse(null);
    }

    public HistoricoPreventivoDTO salvar(HistoricoPreventivoDTO dto) {
        HistoricoPreventivo entity = mapper.toEntity(dto);
        return mapper.toDTO(repository.save(entity));
    }

    public void deletar(UUID id) {
        repository.deleteById(id);
    }

    public HistoricoPreventivoDTO atualizar(UUID id, HistoricoPreventivoDTO dto) {
        if (!repository.existsById(id)) return null;
        dto.setId(id);
        return salvar(dto);
    }
}
