package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.EquipamentoDTO;
import com.bd2.sistemamanutencao.entity.Equipamento;

public class EquipamentoMapper {

    public static EquipamentoDTO toDTO(Equipamento e) {
        return EquipamentoDTO.builder()
                .id(e.getId())
                .nome(e.getNome())
                .modelo(e.getModelo())
                .fabricante(e.getFabricante())
                .build();
    }

    public static Equipamento toEntity(EquipamentoDTO dto) {
        return Equipamento.builder()
                .id(dto.getId())
                .nome(dto.getNome())
                .modelo(dto.getModelo())
                .fabricante(dto.getFabricante())
                .build();
    }
}
