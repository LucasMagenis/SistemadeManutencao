package com.bd2.sistemamanutencao.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "historico")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HistoricoPreventivo {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private UUID id;

    @Column(name = "equipamento_id", nullable = false)
    private UUID idEquipamento;

    @Column(name = "tipo_manutencao", length = 50)
    private String tipoManutencao;

    @Column(name = "data_ultimo_servico")
    private LocalDate dataUltimoServico;

    @Column(name = "data_proximo_servico")
    private LocalDate dataProximoServico;
}
