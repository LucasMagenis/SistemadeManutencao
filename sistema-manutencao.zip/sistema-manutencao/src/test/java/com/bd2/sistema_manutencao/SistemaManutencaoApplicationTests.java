package com.bd2.sistema_manutencao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaManutencaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
