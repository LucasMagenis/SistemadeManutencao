package com.bd2.sistemamanutencao.service;

import com.bd2.sistemamanutencao.entity.Equipamento;
import com.bd2.sistemamanutencao.repository.EquipamentoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EquipamentoService {

    private final EquipamentoRepository repository;

    public EquipamentoService(EquipamentoRepository repository) {
        this.repository = repository;
    }

    public List<Equipamento> listarTodos() {
        return repository.findAll();
    }

    public Optional<Equipamento> buscarPorId(Integer id) {
        return repository.findById(id);
    }

    public Equipamento salvar(Equipamento equipamento) {
        return repository.save(equipamento);
    }

    public void deletar(Integer id) {
        repository.deleteById(id);
    }

    public Equipamento atualizar(Integer id, Equipamento novo) {
        return repository.findById(id).map(e -> {
            e.setNomeEquipamento(novo.getNomeEquipamento());
            e.setDescricao(novo.getDescricao());
            e.setStatus(novo.getStatus());
            e.setTipoEquipamento(novo.getTipoEquipamento());
            return repository.save(e);
        }).orElseThrow(() -> new RuntimeException("Equipamento não encontrado"));
    }
}
