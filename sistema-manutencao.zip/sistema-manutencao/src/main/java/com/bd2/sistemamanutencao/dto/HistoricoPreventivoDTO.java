package com.bd2.sistemamanutencao.dto;

import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HistoricoPreventivoDTO {

    private UUID id;
    private UUID idEquipamento;
    private LocalDate dataRealizacao;
    private String descricao;
    private UUID idTecnico;
}
