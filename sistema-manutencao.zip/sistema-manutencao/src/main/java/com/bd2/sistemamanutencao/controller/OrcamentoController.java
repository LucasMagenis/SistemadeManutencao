package com.bd2.sistemamanutencao.controller;

import com.bd2.sistemamanutencao.dto.OrcamentoDTO;
import com.bd2.sistemamanutencao.service.OrcamentoService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/orcamento")
public class OrcamentoController {

    private final OrcamentoService service;

    public OrcamentoController(OrcamentoService service) {
        this.service = service;
    }

    @GetMapping
    public List<OrcamentoDTO> listarTodos() {
        return service.listarTodos();
    }

    @GetMapping("/{id}")
    public OrcamentoDTO buscarPorId(@PathVariable UUID id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public OrcamentoDTO salvar(@RequestBody OrcamentoDTO dto) {
        return service.salvar(dto);
    }

    @PutMapping("/{id}")
    public OrcamentoDTO atualizar(@PathVariable UUID id, @RequestBody OrcamentoDTO dto) {
        return service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable UUID id) {
        service.deletar(id);
    }
}
