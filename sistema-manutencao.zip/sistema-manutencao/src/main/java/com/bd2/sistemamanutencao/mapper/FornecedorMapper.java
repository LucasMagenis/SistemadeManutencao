package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.FornecedorDTO;
import com.bd2.sistemamanutencao.entity.Fornecedor;
import org.springframework.stereotype.Component;

@Component
public class FornecedorMapper {

    public FornecedorDTO toDTO(Fornecedor entity) {
        return new FornecedorDTO(
        );
    }

    public Fornecedor toEntity(FornecedorDTO dto) {
        Fornecedor entity = new Fornecedor();
        entity.setId(dto.getId());
        entity.setNome(dto.getNome());
        entity.setContato(dto.getContato());
        entity.setTelefone(dto.getTelefone());
        entity.setEmail(dto.getEmail());
        entity.setEndereco(dto.getEndereco());
        return entity;
    }
}
