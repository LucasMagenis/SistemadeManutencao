package com.bd2.sistemamanutencao.controller;

import com.bd2.sistemamanutencao.dto.FalhaDTO;
import com.bd2.sistemamanutencao.service.FalhaService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/falhas")
public class FalhaController {

    private final FalhaService service;

    public FalhaController(FalhaService service) {
        this.service = service;
    }

    @GetMapping
    public List<FalhaDTO> listarTodas() {
        return service.listarTodas();
    }

    @GetMapping("/{id}")
    public FalhaDTO buscarPorId(@PathVariable UUID id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public FalhaDTO salvar(@RequestBody FalhaDTO dto) {
        return service.salvar(dto);
    }

    @PutMapping("/{id}")
    public FalhaDTO atualizar(@PathVariable UUID id, @RequestBody FalhaDTO dto) {
        return service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable UUID id) {
        service.deletar(id);
    }
}
