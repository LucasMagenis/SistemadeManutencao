package com.bd2.sistemamanutencao.dto;

import java.util.UUID;

public class TecnicoDTO {
    private UUID id;
    private String nome;
    private String especialidade;
    private String contato;

    public void setId(UUID id) {
    }

    public UUID getId() {
        return id;
    }

    public String getContato() {
        return contato;
    }

    public void setContato(String contato) {
        this.contato = contato;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    // Getters e Setters
}
