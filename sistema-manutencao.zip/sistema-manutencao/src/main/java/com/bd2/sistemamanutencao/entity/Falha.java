package com.bd2.sistemamanutencao.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Falha {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "org.hibernate.id.UUIDGenerator")
    private UUID id;

    private String descricao;

    private LocalDate dataDeteccao;

    public UUID getIdEquipamento() {
        return idEquipamento;
    }

    public void setIdEquipamento(UUID idEquipamento) {
        this.idEquipamento = idEquipamento;
    }

    public UUID getIdTecnico() {
        return idTecnico;
    }

    public void setIdTecnico(UUID idTecnico) {
        this.idTecnico = idTecnico;
    }

    public LocalDate getDataDeteccao() {
        return dataDeteccao;
    }

    public void setDataDeteccao(LocalDate dataDeteccao) {
        this.dataDeteccao = dataDeteccao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    private UUID idEquipamento;

    private UUID idTecnico;
}
