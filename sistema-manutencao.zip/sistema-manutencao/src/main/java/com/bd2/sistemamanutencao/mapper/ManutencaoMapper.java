package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.ManutencaoDTO;
import com.bd2.sistemamanutencao.entity.Manutencao;
import org.springframework.stereotype.Component;

@Component
public class ManutencaoMapper {

    public ManutencaoDTO toDTO(Manutencao manutencao) {
        return new ManutencaoDTO(
                manutencao.getId(),
                manutencao.getData(),
                manutencao.getTipo(),
                manutencao.getDescricao(),
                manutencao.getIdEquipamento(),
                manutencao.getIdTecnico()
        );
    }

    public Manutencao toEntity(ManutencaoDTO dto) {
        Manutencao manutencao = new Manutencao();
        manutencao.setId(dto.getId());
        manutencao.setData(dto.getData());
        manutencao.setTipo(dto.getTipo());
        manutencao.setDescricao(dto.getDescricao());
        manutencao.setIdEquipamento(dto.getIdEquipamento());
        manutencao.setIdTecnico(dto.getIdTecnico());
        return manutencao;
    }
}
