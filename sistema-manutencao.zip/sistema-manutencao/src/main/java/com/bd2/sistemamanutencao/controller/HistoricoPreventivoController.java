package com.bd2.sistemamanutencao.controller;

import com.bd2.sistemamanutencao.dto.FalhaDTO;
import com.bd2.sistemamanutencao.service.HistoricoPreventivoService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/historico-preventivo")
public class HistoricoPreventivoController {

    private final HistoricoPreventivoService service;

    public HistoricoPreventivoController(HistoricoPreventivoService service) {
        this.service = service;
    }

    @GetMapping
    public List<FalhaDTO.HistoricoPreventivoDTO> listarTodos() {
        return service.listarTodos();
    }

    @GetMapping("/{id}")
    public FalhaDTO.HistoricoPreventivoDTO buscarPorId(@PathVariable UUID id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public FalhaDTO.HistoricoPreventivoDTO salvar(@RequestBody FalhaDTO.HistoricoPreventivoDTO dto) {
        return service.salvar(dto);
    }

    @PutMapping("/{id}")
    public FalhaDTO.HistoricoPreventivoDTO atualizar(@PathVariable UUID id, @RequestBody FalhaDTO.HistoricoPreventivoDTO dto) {
        return service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable UUID id) {
        service.deletar(id);
    }
}
