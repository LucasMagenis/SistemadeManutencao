package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.OrcamentoDTO;
import com.bd2.sistemamanutencao.entity.Fornecedor;
import com.bd2.sistemamanutencao.entity.Orcamento;
import com.bd2.sistemamanutencao.repository.FornecedorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
public class OrcamentoMapper {

    private final FornecedorRepository fornecedorRepository;

    public OrcamentoMapper(FornecedorRepository fornecedorRepository) {
        this.fornecedorRepository = fornecedorRepository;
    }

    public OrcamentoDTO toDTO(Orcamento entity) {
        OrcamentoDTO dto = new OrcamentoDTO();
        dto.setId(entity.getId());
        dto.setDescricao(entity.getDescricao());
        dto.setValor(entity.getValor());
        dto.setDataValidade(entity.getDataValidade());
        if (entity.getFornecedor() != null) {
            dto.setFornecedorId(entity.getFornecedor().getId());
        }
        return dto;
    }

    public Orcamento toEntity(OrcamentoDTO dto) {
        Orcamento entity = new Orcamento();
        entity.setId(dto.getId());
        entity.setDescricao(dto.getDescricao());
        entity.setValor(dto.getValor());
        entity.setDataValidade(dto.getDataValidade());

        if (dto.getFornecedorId() != null) {
            Fornecedor fornecedor = fornecedorRepository.findById(dto.getFornecedorId()).orElse(null);
            entity.setFornecedor(fornecedor);
        } else {
            entity.setFornecedor(null);
        }

        return entity;
    }
}
