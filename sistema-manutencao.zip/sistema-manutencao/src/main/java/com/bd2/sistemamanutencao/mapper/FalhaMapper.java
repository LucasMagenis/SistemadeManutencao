package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.FalhaDTO;
import com.bd2.sistemamanutencao.entity.Falha;
import org.springframework.stereotype.Component;

@Component
public class FalhaMapper {

    public FalhaDTO toDTO(Falha falha) {
        return new FalhaDTO(
        );
    }

    public Falha toEntity(FalhaDTO dto) {
        Falha falha = new Falha();
        falha.setId(dto.getId());
        falha.setDescricao(dto.getDescricao());
        falha.setDataDeteccao(dto.getDataDeteccao());
        falha.setIdEquipamento(dto.getIdEquipamento());
        falha.setIdTecnico(dto.getIdTecnico());
        return falha;
    }
}
