package com.bd2.sistemamanutencao.service;

import com.bd2.sistemamanutencao.dto.OrcamentoDTO;
import com.bd2.sistemamanutencao.entity.Orcamento;
import com.bd2.sistemamanutencao.mapper.OrcamentoMapper;
import com.bd2.sistemamanutencao.repository.OrcamentoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class OrcamentoService {

    private final OrcamentoRepository repository;
    private final OrcamentoMapper mapper;

    public OrcamentoService(OrcamentoRepository repository, OrcamentoMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public List<OrcamentoDTO> listarTodos() {
        return repository.findAll().stream().map(mapper::toDTO).collect(Collectors.toList());
    }

    public OrcamentoDTO buscarPorId(UUID id) {
        return repository.findById(id).map(mapper::toDTO).orElse(null);
    }

    public OrcamentoDTO salvar(OrcamentoDTO dto) {
        Orcamento entity = mapper.toEntity(dto);
        return mapper.toDTO(repository.save(entity));
    }

    public void deletar(UUID id) {
        repository.deleteById(id);
    }

    public OrcamentoDTO atualizar(UUID id, OrcamentoDTO dto) {
        if (!repository.existsById(id)) return null;
        dto.setId(id);
        return salvar(dto);
    }
}
