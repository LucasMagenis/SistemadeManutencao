package com.bd2.sistemamanutencao.controller;

import com.bd2.sistemamanutencao.dto.TecnicoDTO;
import com.bd2.sistemamanutencao.service.TecnicoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/tecnicos")
public class TecnicoController {

    private final TecnicoService tecnicoService;

    public TecnicoController(TecnicoService tecnicoService) {
        this.tecnicoService = tecnicoService;
    }

    @GetMapping
    public List<TecnicoDTO> listarTodos() {
        return tecnicoService.listarTodos();
    }

    @GetMapping("/{id}")
    public TecnicoDTO buscarPorId(@PathVariable UUID id) {
        return tecnicoService.buscarPorId(id);
    }

    @PostMapping
    public TecnicoDTO salvar(@RequestBody TecnicoDTO dto) {
        return tecnicoService.salvar(dto);
    }

    @PutMapping("/{id}")
    public TecnicoDTO atualizar(@PathVariable UUID id, @RequestBody TecnicoDTO dto) {
        return tecnicoService.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable UUID id) {
        tecnicoService.deletar(id);
    }
}
