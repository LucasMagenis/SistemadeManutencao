package com.bd2.sistemamanutencao.service;

import com.bd2.sistemamanutencao.dto.FalhaDTO;
import com.bd2.sistemamanutencao.entity.Falha;
import com.bd2.sistemamanutencao.mapper.FalhaMapper;
import com.bd2.sistemamanutencao.repository.FalhaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service

public class FalhaService {

    private final FalhaRepository repository;
    private final FalhaMapper mapper;

    public FalhaService(FalhaRepository repository, FalhaMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public List<FalhaDTO> listarTodas() {
        return repository.findAll().stream().map(mapper::toDTO).collect(Collectors.toList());
    }

    public FalhaDTO buscarPorId(UUID id) {
        return repository.findById(id).map(mapper::toDTO).orElse(null);
    }

    public FalhaDTO salvar(FalhaDTO dto) {
        Falha falha = mapper.toEntity(dto);
        return mapper.toDTO(repository.save(falha));
    }

    public void deletar(UUID id) {
        repository.deleteById(id);
    }

    public FalhaDTO atualizar(UUID id, FalhaDTO dto) {
        if (!repository.existsById(id)) return null;
        dto.setId(id);
        return salvar(dto);
    }
}
