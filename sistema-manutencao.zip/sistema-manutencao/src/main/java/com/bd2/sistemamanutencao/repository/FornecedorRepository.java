package com.bd2.sistemamanutencao.repository;

import com.bd2.sistemamanutencao.entity.Fornecedor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface FornecedorRepository extends JpaRepository<Fornecedor, UUID> {
}
