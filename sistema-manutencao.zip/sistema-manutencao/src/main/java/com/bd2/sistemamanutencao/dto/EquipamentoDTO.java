package com.bd2.sistemamanutencao.dto;

public class EquipamentoDTO {
    private String nomeEquipamento;
    private String descricao;
    private String status;
    private String tipoEquipamento;
}
