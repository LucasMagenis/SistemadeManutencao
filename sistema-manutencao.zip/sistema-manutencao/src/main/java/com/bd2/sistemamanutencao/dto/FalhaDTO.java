package com.bd2.sistemamanutencao.dto;

import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FalhaDTO {

    private UUID id;
    private String descricao;
    private LocalDate dataDeteccao;
    private UUID idEquipamento;
    private UUID idTecnico;

    public void setId(UUID id) {
    }

    public UUID getId() {
        return null;
    }

    public String getDescricao() {
        return null;
    }

    public LocalDate getDataDeteccao() {
        return null;
    }

    public UUID getIdEquipamento() {
        return null;
    }

    public UUID getIdTecnico() {
        return null;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HistoricoPreventivoDTO {

        private UUID id;
        private UUID idEquipamento;
        private LocalDate dataRealizacao;
        private String descricao;
        private UUID idTecnico;

        public void setId(UUID id) {

        }
    }
}
