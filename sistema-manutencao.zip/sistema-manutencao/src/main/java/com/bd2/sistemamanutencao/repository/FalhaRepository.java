package com.bd2.sistemamanutencao.repository;

import com.bd2.sistemamanutencao.entity.Falha;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface FalhaRepository extends JpaRepository<Falha, UUID> {
}
