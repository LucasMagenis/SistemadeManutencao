package com.bd2.sistemamanutencao.service;

import com.bd2.sistemamanutencao.dto.FalhaDTO;
import com.bd2.sistemamanutencao.entity.HistoricoPreventivo;
import com.bd2.sistemamanutencao.mapper.HistoricoPreventivoMapper;
import com.bd2.sistemamanutencao.repository.HistoricoPreventivoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class HistoricoPreventivoService {

    private final HistoricoPreventivoRepository repository;
    private final HistoricoPreventivoMapper mapper;

    public HistoricoPreventivoService(HistoricoPreventivoRepository repository, HistoricoPreventivoMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public List<FalhaDTO.HistoricoPreventivoDTO> listarTodos() {
        return repository.findAll().stream().map(mapper::toDTO).collect(Collectors.toList());
    }

    public FalhaDTO.HistoricoPreventivoDTO buscarPorId(UUID id) {
        return repository.findById(id).map(mapper::toDTO).orElse(null);
    }

    public FalhaDTO.HistoricoPreventivoDTO salvar(FalhaDTO.HistoricoPreventivoDTO dto) {
        HistoricoPreventivo entity = mapper.toEntity(dto);
        return mapper.toDTO(repository.save(entity));
    }

    public void deletar(UUID id) {
        repository.deleteById(id);
    }

    public FalhaDTO.HistoricoPreventivoDTO atualizar(UUID id, FalhaDTO.HistoricoPreventivoDTO dto) {
        if (!repository.existsById(id)) return null;
        dto.setId(id);
        return salvar(dto);
    }
}
