package com.bd2.sistemamanutencao.service;

import com.bd2.sistemamanutencao.dto.PecaDTO;
import com.bd2.sistemamanutencao.entity.Peca;
import com.bd2.sistemamanutencao.mapper.PecaMapper;
import com.bd2.sistemamanutencao.repository.PecaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class PecaService {

    private final PecaRepository repository;
    private final PecaMapper mapper;

    public PecaService(PecaRepository repository, PecaMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public List<PecaDTO> listarTodos() {
        return repository.findAll().stream().map(mapper::toDTO).collect(Collectors.toList());
    }

    public PecaDTO buscarPorId(UUID id) {
        return repository.findById(id).map(mapper::toDTO).orElse(null);
    }

    public PecaDTO salvar(PecaDTO dto) {
        Peca entity = mapper.toEntity(dto);
        return mapper.toDTO(repository.save(entity));
    }

    public void deletar(UUID id) {
        repository.deleteById(id);
    }

    public PecaDTO atualizar(UUID id, PecaDTO dto) {
        if (!repository.existsById(id)) return null;
        dto.setId(id);
        return salvar(dto);
    }
}
