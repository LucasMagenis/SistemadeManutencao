package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.FalhaDTO;
import com.bd2.sistemamanutencao.entity.HistoricoPreventivo;
import org.springframework.stereotype.Component;

@Component
public class HistoricoPreventivoMapper {

    public FalhaDTO.HistoricoPreventivoDTO toDTO(HistoricoPreventivo entity) {
        return new FalhaDTO.HistoricoPreventivoDTO(
        );
    }

    public HistoricoPreventivo toEntity(FalhaDTO.HistoricoPreventivoDTO dto) {
        HistoricoPreventivo entity = new HistoricoPreventivo();
        entity.setId(dto.getId());
        entity.setIdEquipamento(dto.getIdEquipamento());
        entity.setDataRealizacao(dto.getDataRealizacao());
        entity.setDescricao(dto.getDescricao());
        entity.setIdTecnico(dto.getIdTecnico());
        return entity;
    }
}
