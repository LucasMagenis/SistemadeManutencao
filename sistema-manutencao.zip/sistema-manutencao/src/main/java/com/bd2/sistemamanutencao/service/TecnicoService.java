package com.bd2.sistemamanutencao.service;

import com.bd2.sistemamanutencao.dto.TecnicoDTO;
import com.bd2.sistemamanutencao.entity.Tecnico;
import com.bd2.sistemamanutencao.mapper.TecnicoMapper;
import com.bd2.sistemamanutencao.repository.TecnicoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class TecnicoService {

    private final TecnicoRepository tecnicoRepository;

    public TecnicoService(TecnicoRepository tecnicoRepository) {
        this.tecnicoRepository = tecnicoRepository;
    }

    public List<TecnicoDTO> listarTodos() {
        return tecnicoRepository.findAll()
                .stream()
                .map(TecnicoMapper::toDTO)
                .collect(Collectors.toList());
    }

    public TecnicoDTO buscarPorId(UUID id) {
        return tecnicoRepository.findById(id)
                .map(TecnicoMapper::toDTO)
                .orElse(null);
    }

    public TecnicoDTO salvar(TecnicoDTO dto) {
        Tecnico tecnico = TecnicoMapper.toEntity(dto);
        tecnico = tecnicoRepository.save(tecnico);
        return TecnicoMapper.toDTO(tecnico);
    }

    public void deletar(UUID id) {
        tecnicoRepository.deleteById(id);
    }

    public TecnicoDTO atualizar(UUID id, TecnicoDTO dto) {
        if (tecnicoRepository.existsById(id)) {
            dto.setId(id);
            return salvar(dto);
        }
        return null;
    }
}
