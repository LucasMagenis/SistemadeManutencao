package com.bd2.sistemamanutencao.mapper;

import com.bd2.sistemamanutencao.dto.PecaDTO;
import com.bd2.sistemamanutencao.entity.Peca;
import org.springframework.stereotype.Component;

@Component
public class PecaMapper {

    public PecaDTO toDTO(Peca peca) {
        return new PecaDTO(
        );
    }

    public Peca toEntity(PecaDTO dto) {
        Peca peca = new Peca();
        peca.setId(dto.getId());
        peca.setNome(dto.getNome());
        peca.setFabricante(dto.getFabricante());
        peca.setQuantidadeEstoque(dto.getQuantidadeEstoque());
        return peca;
    }
}
