package com.bd2.sistemamanutencao.dto;

import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
public class ManutencaoDTO {

    private UUID id;
    private LocalDate data;
    private String tipo;
    private String descricao;
    private UUID idEquipamento;
    private UUID idTecnico;

    public ManutencaoDTO(UUID id, LocalDate data, String tipo, String descricao, UUID idEquipamento, UUID idTecnico) {
    }

    public UUID getIdTecnico() {
        return idTecnico;
    }

    public void setIdTecnico(UUID idTecnico) {
        this.idTecnico = idTecnico;
    }

    public UUID getIdEquipamento() {
        return idEquipamento;
    }

    public void setIdEquipamento(UUID idEquipamento) {
        this.idEquipamento = idEquipamento;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public UUID getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public void setId(UUID id) {

    }
}
